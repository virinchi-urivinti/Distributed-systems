package edu.buffalo.cse.cse486586.simpledht;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Formatter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.concurrent.ExecutionException;

import android.app.Activity;
import android.content.ContentProvider;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MergeCursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.util.Log;
import  android.database.MatrixCursor;

public class SimpleDhtProvider extends ContentProvider {

  static final String TAG = SimpleDhtProvider.class.getSimpleName();
  static final String[] REMOTE_PORT = {"11108","11112","11116","11120","11124"};
  static final int SERVER_PORT = 10000;
  private static final String KEY_FIELD = "key";
  private static final String VALUE_FIELD = "value";


  static final String[] node_ids = {"","","","",""};
  ArrayList present_nodes = new ArrayList();   // store the present nodes in emulator - 5554 and give the list to all
  ArrayList<String> received_nodes;
  ArrayList<String> hashed_received_nodes = new ArrayList<String>();

  String myPort;
  String pred = ""; // Predecessor node
  String succ = ""; // Successor node
  int chord_no = 1;

  Uri uri = buildUri("content", "edu.buffalo.cse.cse486586.simpledht.provider");



  private SQLiteDatabase db;
  private SQLiteDatabase mdb;
  private DictOpenHelper dictOpenHelper;




  public class DictOpenHelper extends SQLiteOpenHelper {      //SOURCE: https://developer.android.com/guide/topics/data/data-storage.html#db

    private static final int DATABASE_VERSION = 2;
    private static final String DB_TABLE_NAME = "KEY_VALUE";
    private static final String KEY_FIELD = "key";
    private static final String VALUE_FIELD = "value";
    private static final String DATABASE_NAME = "key_value.db";
    private static final String DB_TABLE_CREATE =
            "CREATE TABLE " + DB_TABLE_NAME + " (" +
                    KEY_FIELD + " TEXT , " +
                    VALUE_FIELD + " TEXT, " +
                    "UNIQUE(" + KEY_FIELD + ") ON CONFLICT REPLACE);";


    DictOpenHelper(Context context) {
      super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
      //db.execSQL("DROP TABLE IF EXISTS" + DB_TABLE_NAME);
      //db.delete(DB_TABLE_NAME, null, null);
      db.execSQL(DB_TABLE_CREATE);



    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

      //CopyNewDatabaseFromAsset();
      db.execSQL("DROP TABLE IF EXISTS" + DB_TABLE_NAME);
      onCreate(db);


    }

  }

  public  class HashComparator implements Comparator<String >{   // Comparison using the hash values generated

    public int compare(String s1, String s2){
      try{

        int s1_int = Integer.parseInt(s1);
        int s2_int = Integer.parseInt(s2);

        return (genHash(Integer.toString(s1_int/2)).compareTo(genHash(Integer.toString(s2_int/2)))) ;

      }catch(NoSuchAlgorithmException e){
        Log.e("Inside HashComparator:","Error in genHash");
        return 0;
      }

    }
  }


  @Override
  public int delete(Uri uri, String selection, String[] selectionArgs) {

    // TODO Auto-generated method stub

    db = dictOpenHelper.getWritableDatabase();
    db.delete(dictOpenHelper.DB_TABLE_NAME,null,null);
    return 0;
  }

  @Override
  public String getType(Uri uri) {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public Uri insert(Uri uri, ContentValues values) {
    // TODO Auto-generated method stub

    db = dictOpenHelper.getWritableDatabase();
    String curr_node_id ;
    String object_id;
    String pred_hash;

    try{

      Log.i("key in values in insert",values.get("key").toString());
      object_id = genHash(values.get("key").toString());
      Log.v("object_id",object_id);   // object_id - hashed value of key
      curr_node_id = genHash(Integer.toString(Integer.parseInt(myPort)/2));





      if(chord_no == 1){     // only one node is present in  the chord

        long rowID = db.insert(dictOpenHelper.DB_TABLE_NAME, null, values);
        Uri newuri;

        if (rowID > 0) {
          newuri = ContentUris.withAppendedId(uri, rowID);
          getContext().getContentResolver().notifyChange(newuri, null);

          return newuri;
        }
        Log.i("Chord_no","1!!!!!");


        Log.v("insert", values.toString());
        return uri;




      }
       else if( (object_id.compareTo(hashed_received_nodes.get(0))<0 ) || (object_id.compareTo(hashed_received_nodes.get(hashed_received_nodes.size() - 1)) > 0) ){
            //All exception cases are handled, these do not fall in any of the ring ranges
            String key_part = values.get(KEY_FIELD).toString();
            String value_part = values.get(VALUE_FIELD).toString();

            if(value_part.charAt(value_part.length()-1) != '#'){

                String valuesToBeSent = key_part + "$" + value_part + "#";  //sending content values as a string ; # indicates that it has to be sent to minimum node

                new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, valuesToBeSent , myPort);

                Log.v("Inside insert()","Forward the values to next node::" + valuesToBeSent);



            }
            else{

                value_part = value_part.substring(0,value_part.length()-1);   // remove # at the end
                Log.i("Removed #",value_part);

                ContentValues cv = new ContentValues();

                cv.put(KEY_FIELD,key_part);
                cv.put(VALUE_FIELD,value_part);

                long rowID = db.insert(dictOpenHelper.DB_TABLE_NAME, null, cv);
                Uri newuri;

                if (rowID > 0) {
                    newuri = ContentUris.withAppendedId(uri, rowID);
                    getContext().getContentResolver().notifyChange(newuri, null);

                    return newuri;
                }
                Log.i("last else in insert:","insert in minimum node");


                Log.v("insert", cv.toString());
                return uri;

            }


        }

      else if(((object_id.compareTo(curr_node_id)<= 0) && (object_id.compareTo(genHash(Integer.toString(Integer.parseInt(pred)/2)))>0)) ){


        long rowID = db.insert(dictOpenHelper.DB_TABLE_NAME, null, values);
        Uri newuri;

        if (rowID > 0) {
          newuri = ContentUris.withAppendedId(uri, rowID);
          getContext().getContentResolver().notifyChange(newuri, null);

          return newuri;
        }



        Log.v("insert", values.toString());
        return uri;

      }
      else{

          // forward the values to the next

        String key_part = values.get(KEY_FIELD).toString();
        String value_part = values.get(VALUE_FIELD).toString();

        String valuesToBeSent = key_part + "$" + value_part;

        new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, valuesToBeSent , myPort);

        Log.v("Inside insert()","Forward the values to next node::" + valuesToBeSent);





      }



    }catch (NoSuchAlgorithmException e){
      Log.e("Inside insert() :", "Error in gen hash");
    }


    //long rowID = db.insert(dictOpenHelper.DB_TABLE_NAME, null, values);


    return uri;
  }

  @Override
  public boolean onCreate() {

    // TODO Auto-generated method stub
    Context context = getContext();
    dictOpenHelper = new DictOpenHelper(context);  //one-time initialization



        /*
         * Calculate the port number that this AVD listens on.
         * It is just a hack that I came up with to get around the networking limitations of AVDs.
         * The explanation is provided in the PA1 spec.
         *  @author steve ko
         */
    TelephonyManager tel = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
    String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
    myPort = String.valueOf((Integer.parseInt(portStr) * 2));

    try {
            /*
             * Create a server socket as well as a thread (AsyncTask) that listens on the server
             * port.
             *
             * AsyncTask is a simplified thread construct that Android provides. Please make sure
             * you know how it works by reading
             * http://developer.android.com/reference/android/os/AsyncTask.html
             */
      ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
      new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);




    } catch (IOException e) {
            /*
             * Log is a good way to debug your code. LogCat prints out all the messages that
             * Log class writes.
             *
             * Please read http://developer.android.com/tools/debugging/debugging-projects.html
             * and http://developer.android.com/tools/debugging/debugging-log.html
             * for more information on debugging.
             */
      Log.e(TAG, "Can't create a ServerSocket");
      return false;
    }

    if(!myPort.equals("11108")){
      // new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, "Joining the chord", myPort);  // send myport on creation

      new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, myPort , myPort);
      Log.v("Inside onCreate","Sending the join request");
    }
    else{
      present_nodes.add("11108"); // "11108" is always present
    }



    return true;




  }

  @Override
  public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs,
                      String sortOrder) {
    // TODO Auto-generated method stub

    //SOURCE: https://developer.android.com/reference/android/content/ContentProvider.html#query(android.net.Uri,%20java.lang.String[],%20java.lang.String,%20java.lang.String[],%20java.lang.String)


    // SQLiteQueryBuilder is a helper class that creates the
    // proper SQL syntax for us.
    mdb = dictOpenHelper.getReadableDatabase();

    SQLiteQueryBuilder qBuilder = new SQLiteQueryBuilder();

    qBuilder.setTables(dictOpenHelper.DB_TABLE_NAME);  //Set the table we're querying.
    Log.v("c", mdb.toString());
    Cursor c ;


    if(chord_no == 1){

      // Make the query by using qBuilder.
      if (selection.equals("*") || selection.equals("@") ){  // for one node, @ and * does the same operation
        Log.v("selection","by * operator");
        c = qBuilder.query(mdb,
                projection,
                null,  //   null will return all rows.                Source: query in https://developer.android.com/reference/android/database/sqlite/SQLiteDatabase.html
                selectionArgs,
                null,
                null,
                sortOrder);




      }else{


        String sel = "key = " + "'" + selection + "'" ;
        Log.v("selection",sel);
        Log.i("inChord=1","else part");
        c = qBuilder.query(mdb,
                projection,
                sel,
                selectionArgs,
                null,
                null,
                sortOrder);




      }


    }
    else if (selection.equals("@") ){       // get all key, value pairs in local node
      Log.v("selection","by @ operator");
      c = qBuilder.query(mdb,
              projection,
              null,  //   null will return all rows.
              selectionArgs,
              null,
              null,
              sortOrder);




    }
    else if(selection.equals("*")){  // get all key, value pairs in all nodes

      Log.v("selection","by * operator");
      c = qBuilder.query(mdb,
              projection,
              null,  //   null will return all rows in local node.
              selectionArgs,
              null,
              null,
              sortOrder);

      MatrixCursor matrixCursor = new MatrixCursor(new String[]{KEY_FIELD,VALUE_FIELD});    // source: http://stackoverflow.com/questions/9917935/adding-rows-into-cursor-manually


      //sending query request to all nodes as all^portnumber

      for(int i=0; i<received_nodes.size();i++){

        if(!myPort.equals(received_nodes.get(i))){



          String all_request = "all"+ "," + received_nodes.get(i);

          try{

            String results = new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, all_request, myPort).get();

            if(!results.equals("no rows")){

              String[] result_rows = results.split("\\;");
              for (String row : result_rows) {

                String[] kv_parts = row.split("\\?");
                String res_key = kv_parts[0];
                String res_value = kv_parts[1];
                matrixCursor.addRow(new String[]{res_key , res_value} );


              }

            }




          }catch (InterruptedException e) {

            Log.e("Inside * query:", "InterruptedException");

          } catch (ExecutionException e) {

            Log.e("Inside * query:", "ExecutionException");

          }



        }


      }







      MergeCursor mergeCursor = new MergeCursor(new Cursor[] { matrixCursor, c });


      return mergeCursor;








    }
    else if(selection.charAt(selection.length()-1) =='+'){

      String sel = "key = " + "'" + selection.substring(0,selection.length()-1) + "'" ;
      Log.v("selection",sel);
      Log.i("in + ", sel);
      c = qBuilder.query(mdb,
              projection,
              sel,
              selectionArgs,
              null,
              null,
              sortOrder);
      Log.i("I'm in +","ok");








    }
    else {  // search the range in which the provided selection key belongs to:

      String sel = "key = " + "'" + selection + "'" ;
      Log.v("selection",sel);
      Log.v("search the range",sel);
      Log.v("received_nodes",received_nodes.toString());



      String gen_query = "";
      String sel_str_sent = "";

      try {
        gen_query = genHash(selection);
      } catch (NoSuchAlgorithmException e) {

        Log.e("Inside query()", "error in hash");

      }

      sel_str_sent = selection + "&" + query_node_finder(gen_query);
      c = null;




      //send query request to the minimum node or the required node.
      try {



        String received_str;
        received_str = new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, sel_str_sent, myPort).get();
        Log.i("Received query res", "from others: " + received_str);

        // received_str has ~ in  between key and value
        String[] returned_res = received_str.split("\\~");
        MatrixCursor matrixCursor = new MatrixCursor(new String[]{KEY_FIELD,VALUE_FIELD});    // source: http://stackoverflow.com/questions/9917935/adding-rows-into-cursor-manually
        matrixCursor.addRow(new String[]{returned_res[0],returned_res[1]});

        matrixCursor.setNotificationUri(getContext().getContentResolver(), uri);


        return matrixCursor;



      } catch (InterruptedException e) {

        Log.e("Inside query:", "InterruptedException");

      } catch (ExecutionException e) {

        Log.e("Inside query:", "ExecutionException");

      }

    }


    c.setNotificationUri(getContext().getContentResolver(), uri);
    return c;
    //return null;
  }

  @Override
  public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
    // TODO Auto-generated method stub
    return 0;
  }


  private ArrayList<String> node_hasher(ArrayList<String> input){

      ArrayList<String> hashed_output = new ArrayList<String>();

      for(int i = 0; i<received_nodes.size();i++){
          try{
              hashed_output.add(genHash(Integer.toString(Integer.parseInt(input.get(i))/2)));
              Log.i("Hashed_output:",hashed_output.toString());

          }catch(NoSuchAlgorithmException e){
              Log.e("error in:","hashed_received_nodes");
          }


      }
      return hashed_output;

  }


  private String query_node_finder(String input){

    int i = 0;
    int max = hashed_received_nodes.size()-2;

    while(i<= max){
      if(input.compareTo(hashed_received_nodes.get(i))> 0 && input.compareTo(hashed_received_nodes.get(i+1))<= 0  ){
        Log.i("in query node finder:",received_nodes.get(i+1));
        return received_nodes.get(i+1);

      }
      i++;
    }


    return received_nodes.get(0);
  }


  private String genHash(String input) throws NoSuchAlgorithmException {
    MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
    byte[] sha1Hash = sha1.digest(input.getBytes());
    Formatter formatter = new Formatter();
    for (byte b : sha1Hash) {
      formatter.format("%02x", b);
    }

    return formatter.toString();

  }

  private Uri buildUri(String scheme, String authority) {  // build the uri
    Uri.Builder uriBuilder = new Uri.Builder();
    uriBuilder.authority(authority);
    uriBuilder.scheme(scheme);
    return uriBuilder.build();
  }

  /***
   * ServerTask is an AsyncTask that should handle incoming messages. It is created by
   * ServerTask.executeOnExecutor() call in SimpleMessengerActivity.
   *
   * Please make sure you understand how AsyncTask works by reading
   * http://developer.android.com/reference/android/os/AsyncTask.html
   *
   * @author stevko
   *
   */
  private class ServerTask extends AsyncTask<ServerSocket, String, Void> {

    @Override
    protected Void doInBackground(ServerSocket... sockets) {
      ServerSocket serverSocket = sockets[0];

            /*
             * TODO: Fill in your server code that receives messages and passes them
             * to onProgressUpdate().
             */
      try {


        String strin;   //based on https://docs.oracle.com/javase/tutorial/networking/sockets/ and android doc



        while (true) {
          Socket socket = serverSocket.accept();
          BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

          if ((strin = in.readLine()) != null) {

            if(myPort.equals("11108")){

              if(strin.equals("11112") || strin.equals("11116") || strin.equals("11120") || strin.equals("11124")){   // a new node wants to join the chord
                present_nodes.add(strin);
                chord_no += 1;
                Log.i("chord_no",(Integer.toString(chord_no)));
                Collections.sort(present_nodes, new HashComparator());   // sorted as per hash values
                Log.i("Present_nodes",present_nodes.toString());



                try {

                  for (String remotePort : REMOTE_PORT) {


                    Socket socket_out = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                            Integer.parseInt(remotePort));


                    try {




                      PrintWriter out = new PrintWriter(socket_out.getOutputStream(), true);

                      out.println(present_nodes.toString());
                      out.flush();





                    } catch (IOException e) {
                      Log.e(TAG, "not able to send messages");
                    }
                    socket.close();
                  }


                } catch (UnknownHostException e) {
                  Log.e(TAG, "Sending present_nodes: UnknownHostException");
                } catch (IOException e) {
                  Log.e(TAG, "Sending present_nodes: socket IOException");
                }




              }
              else if(strin.contains("[")){   // Arraylist is present in the string
                // update the predecessor and successor  for emulator-5554

                Log.i("Got present_nodes  as:",strin);
                Log.i("No.of present_nodes as:",Integer.toString(strin.length()));
                String rem_strin = strin.replace("[", "").replace("]","").replaceAll("\\s","");

                received_nodes = new ArrayList<String>(Arrays.asList(rem_strin.split(",")));      // source: http://stackoverflow.com/questions/7347856/how-to-convert-a-string-into-an-arraylist
                Log.i("received_nodes",received_nodes.toString());

                int port_index = received_nodes.indexOf(myPort);
                int pred_no = (port_index - 1)%(received_nodes.size());

                if(pred_no<0){
                  pred = received_nodes.get(pred_no+received_nodes.size());

                }
                else{
                  pred = received_nodes.get(pred_no);
                }


                succ = received_nodes.get((port_index + 1)%(received_nodes.size()));

                Log.i("Predecessor of"+myPort, pred);

                Log.i("Successor of"+myPort, succ);


                  hashed_received_nodes = node_hasher(received_nodes);

              }
              else if(strin.contains("$")){

                String received_values = strin;   // strin is present as "key,value"

                String[] parts = received_values.split("\\$");
                Log.i("Parts[0]",parts[0]);
                Log.i("Parts[1]",parts[1]);

                ContentValues cv = new ContentValues();

                cv.put(KEY_FIELD,parts[0]);
                cv.put(VALUE_FIELD,parts[1]);





                insert(uri,cv);



              }
              else if(strin.contains("!")){

                String parts[] = strin.split("\\!");   // strin : key&port(from where the key came)
                String port_to_send = parts[1];
                Log.i("Port_to_Send",port_to_send);
                String selection_param = parts[0] + "+";  // + indicates - search only in local partition
                Log.i("Selectparam-servertask ",selection_param);

                Cursor out_cursor = query(uri,null,selection_param,null,null);

                //Socket socket_out = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                    //Integer.parseInt(port_to_send));


                int keyIndex = out_cursor.getColumnIndex(KEY_FIELD);  //based on testclicklistener.java
                int valueIndex = out_cursor.getColumnIndex(VALUE_FIELD);

                out_cursor.moveToFirst();

                String returnKey = out_cursor.getString(keyIndex);
                String returnValue = out_cursor.getString(valueIndex);

                String res_to_send = returnKey + "~" + returnValue;

                Log.i("res_to_Send", res_to_send);



                try {




                  PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

                  out.println(res_to_send);
                  out.flush();
                  out_cursor.close();

                  Log.i("Query: Sending ","res_to_send !!!" + res_to_send);

                  socket.close();


                } catch (IOException e) {
                  Log.e(TAG, "not able to send messages");
                }
                socket.close();




              }
              else if(strin.equals("all")){



                String select = "@";
                Cursor star_cursor = query(uri,null,select,null,null);


                String temp_result = "";
                String out_strin = "";

                if(star_cursor.moveToFirst()){

                  while(star_cursor.isAfterLast() == false){

                    int keyIndex = star_cursor.getColumnIndex(KEY_FIELD);  //based on testclicklistener.java
                    int valueIndex = star_cursor.getColumnIndex(VALUE_FIELD);


                    String returnKey = star_cursor.getString(keyIndex);
                    String returnValue = star_cursor.getString(valueIndex);

                    temp_result = returnKey + "?" + returnValue;
                    Log.i("res_to_Send", temp_result);

                    out_strin = out_strin + ";" + temp_result;

                    star_cursor.moveToNext();






                  }


                }






                try {


                  if(out_strin.length()>0){
                    String final_out = out_strin.substring(1,out_strin.length()); // ignore the ; at the start
                    PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

                    out.println(final_out);
                    out.flush();
                    star_cursor.close();


                    Log.i("Query: Sending ","final_out" + final_out);


                  }
                  else{

                    PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

                    out.println("no rows");
                    out.flush();
                    star_cursor.close();


                    Log.i("Query: Sending ","final_out" + "no rows");


                  }




                } catch (IOException e) {
                  Log.e(TAG, "not able to send messages");
                }
                socket.close();







              }





            }  //below: tasks done by other nodes.
            else if((myPort.equals("11112") || myPort.equals("11116") || myPort.equals("11120") || myPort.equals("11124")) ){

              // update the predecessor and successor for other emulators  OR  try insert()

              if(strin.contains("$")){


                String received_values = strin;   // strin is present as "key,value"

                String[] parts = received_values.split("\\$");
                Log.i("Parts[0]",parts[0]);
                Log.i("Parts[1]",parts[1]);

                ContentValues cv = new ContentValues();

                cv.put(KEY_FIELD,parts[0]);
                cv.put(VALUE_FIELD,parts[1]);


                insert(uri,cv);



              }else if(strin.contains("[")){    // Receive only the arraylist strings

                chord_no +=  1;
                Log.i("Got present_nodes as:",strin);

                String rem_strin = strin.replace("[", "").replace("]","").replaceAll("\\s","");

                received_nodes = new ArrayList<String>(Arrays.asList(rem_strin.split(",")));      // source: http://stackoverflow.com/questions/7347856/how-to-convert-a-string-into-an-arraylist
                Log.i("received_nodes",received_nodes.toString());


                int port_index = received_nodes.indexOf(myPort);
                Log.i("Port_index",Integer.toString(port_index));
                Log.i("Received node size",Integer.toString(received_nodes.size()));
                Log.i("pred no.",Integer.toString((port_index - 1)%(received_nodes.size())));
                Log.i("Succ no.",Integer.toString((port_index + 1)%(received_nodes.size())));
                int pred_no = (port_index - 1)%(received_nodes.size());
                if(pred_no<0){
                  pred = received_nodes.get(pred_no+received_nodes.size());

                }
                else{
                  pred = received_nodes.get(pred_no);
                }

                succ = received_nodes.get(((port_index + 1)%(received_nodes.size())));

                Log.i("Predecessor of"+myPort, pred);

                Log.i("Successor of"+myPort, succ);


                  hashed_received_nodes = node_hasher(received_nodes);




              }
              else if(strin.contains("!")){

                String parts[] = strin.split("\\!");   // strin : key&port(from where the key came)
                String port_to_send = parts[1];
                Log.i("Port_to_Send",port_to_send);
                String selection_param = parts[0] + "+";  // + indicates - search only in local partition
                Log.i("Selectparam-servertask ",selection_param);

                Cursor out_cursor = query(uri,null,selection_param,null,null);

                //Socket socket_out = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                        //Integer.parseInt(port_to_send));


                int keyIndex = out_cursor.getColumnIndex(KEY_FIELD);  //based on testclicklistener.java
                int valueIndex = out_cursor.getColumnIndex(VALUE_FIELD);

                out_cursor.moveToFirst();

                String returnKey = out_cursor.getString(keyIndex);
                String returnValue = out_cursor.getString(valueIndex);

                String res_to_send = returnKey + "~" + returnValue;

                Log.i("res_to_Send", res_to_send);



                try {




                  PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

                  out.println(res_to_send);
                  out.flush();
                  out_cursor.close();


                  Log.i("Query: Sending ","res_to_send !!!" + res_to_send);




                } catch (IOException e) {
                  Log.e(TAG, "not able to send messages");
                }
                socket.close();






              }
              else if(strin.equals("all")){


                String select = "@";
                Cursor star_cursor = query(uri,null,select,null,null);




                String temp_result = "";
                String out_strin = "";

                if(star_cursor.moveToFirst()){

                  while(star_cursor.isAfterLast() == false){

                    int keyIndex = star_cursor.getColumnIndex(KEY_FIELD);  //based on testclicklistener.java
                    int valueIndex = star_cursor.getColumnIndex(VALUE_FIELD);


                    String returnKey = star_cursor.getString(keyIndex);
                    String returnValue = star_cursor.getString(valueIndex);

                    temp_result = returnKey + "?" + returnValue;
                    Log.i("temp_result", temp_result);

                    out_strin = out_strin + ";" + temp_result;

                    star_cursor.moveToNext();






                  }



                }






                try {

                  if(out_strin.length()>0){
                    String final_out = out_strin.substring(1,out_strin.length()); // ignore the ; at the start
                    PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

                    out.println(final_out);
                    out.flush();
                    star_cursor.close();


                    Log.i("Query: Sending ","final_out" + final_out);


                  }
                  else{

                    PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

                    out.println("no rows");
                    out.flush();
                    star_cursor.close();


                    Log.i("Query: Sending ","final_out" + "no rows");


                  }




                } catch (IOException e) {
                  Log.e(TAG, "not able to send messages");
                }
                socket.close();







              }




            }


            socket.close();

          }

        }





      } catch (IOException e) {
        Log.e(TAG, "not able to receive messages");
      }


      return null;
    }


  }

  /***
   * ClientTask is an AsyncTask that should send a string over the network.
   * It is created by ClientTask.executeOnExecutor() call whenever OnKeyListener.onKey() detects
   * an enter key press event.
   *
   * @author stevko
   *
   */
  private class ClientTask extends AsyncTask<String, Void , String> {

    @Override
    protected String doInBackground(String... msgs) {
      try {

        if(msgs[0].contains("$") && !msgs[0].contains("#") ){    // send "values" to successor

          Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                  Integer.parseInt(succ));

          Log.i("Sending"+ msgs[0], "to" + succ);

          String msgToSend = msgs[0];


          try {


            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

            out.println(msgToSend);
            out.flush();

          } catch (IOException e) {
            Log.e(TAG, "not able to send messages");
          }
          socket.close();


        }
        else if(msgs[0].contains("#")&& msgs[0].contains("$")){

          Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                  Integer.parseInt(received_nodes.get(0)));

          Log.i("Sending -> "+ msgs[0], "to" + received_nodes.get(0));

          String msgToSend = msgs[0];

          try {


            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

            out.println(msgToSend);
            out.flush();

          } catch (IOException e) {
            Log.e(TAG, "not able to send messages");
          }
          socket.close();



        }
        else if(msgs[0].contains("&")  ){

          String[] query_part = msgs[0].split("\\&");  // query parts: key&minimumnode OR key&node
          Log.i("query_parts",query_part.toString());
          String port_to_send = query_part[1];
          String key_part = query_part[0];
          Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                  Integer.parseInt(port_to_send));

          String msgToSend = key_part + "!" + myPort ;  // send as key ! myport


          try {

            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader client_in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            String res_string;


              out.println(msgToSend);
              out.flush();

              while(true){
                if((res_string = client_in.readLine()) != null){


                  Log.i("Got res_string as:",res_string);
                  break;



                }
              }



            return res_string;







          } catch (IOException e) {
            Log.e(TAG, "not able to send messages");
          }
          socket.close();



        }
        else if(msgs[0].contains(",")){

          String[] parts = msgs[0].split("\\,");
          Log.i("port_to_Send in *",parts[1]);
          String port_to_send = parts[1];
          String msgToSend = parts[0];  //msg is "all"
          Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                  Integer.parseInt(port_to_send));


          try {

            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader client_in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            String full_string;


            out.println(msgToSend);
            out.flush();

            while(true){
              if((full_string = client_in.readLine()) != null){


                Log.i("Got full_string as:",full_string);
                break;



              }
            }



            return full_string;







          } catch (IOException e) {
            Log.e(TAG, "not able to send messages");
          }
          socket.close();






        }
        else{

          for (String remotePort : REMOTE_PORT) {


            Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                    Integer.parseInt(remotePort));

            String msgToSend = msgs[0];
                /*
                 * TODO: Fill in your client code that sends out a message.
                 */
            try {



              PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

              out.println(msgToSend);
              out.flush();



            } catch (IOException e) {
              Log.e(TAG, "not able to send messages");
            }
            socket.close();
          }

        }


      } catch (UnknownHostException e) {
        Log.e(TAG, "ClientTask UnknownHostException");
      } catch (IOException e) {
        Log.e(TAG, "ClientTask socket IOException");
      }
      return null;

    }


  }


}
